		</div><!--Ends Holder Div-->
		</div><!--Ends Column 8 offset 2 Div-->
	</div><!--Ends Row Div-->
</div><!--Ends Fluid Container Div-->

<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-3.1.0.min.js'); ?>"></script>

<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.typist.js'); ?>"></script>

<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>

<script type="text/javascript" src="<?php echo base_url('assets/js/main.js'); ?>"></script>


</body>
</html>