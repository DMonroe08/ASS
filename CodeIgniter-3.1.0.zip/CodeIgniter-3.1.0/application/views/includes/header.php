<!DOCTYPE>
<html lang="en">
<head>
	<meta http-equiv="Content Type" content="text/html; charset=utf-8">
	<title>Recipe Recsue</title>
	<link rel="stylesheet" href="<?php echo base_url("assets/css/main.css"); ?>"/>
	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css"); ?>" />
	<link href="<?php echo base_url('assets/fonts/PoiretOne-Regular.ttf')?>" rel="stylesheet"/>
	
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<div class="holder">
					<div class="row">
						<div class="col-md-12" id="sceme">
							<div class="page-header" ><h1 class="text-center">Recipe Rescue</h1></div>
						</div><!--Ends Column MD 8 Offset 2 Div-->
					</div><!--Ends Row Div-->
					
					